#!/bin/bash
echo "Installing dependencies..."
pip install -r requirements.txt
echo "Starting MaterialMind..."
python3 app_complete.py
